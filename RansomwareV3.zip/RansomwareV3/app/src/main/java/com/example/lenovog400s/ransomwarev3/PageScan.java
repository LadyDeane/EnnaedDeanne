//Developer name: Ennaed Deanne
//Fyp Project 2015/2016

package com.example.lenovog400s.ransomwarev3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PageScan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_scan);


        Button btn_home = (Button) findViewById(R.id.home);



        btn_home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent(PageScan.this,
                        PagePalingDepan.class);
                startActivity(intent);

            }
        });

    }

    @Override
    Public class scanner example {
        public static void main (string args[]) throws
                FileNotFoundException {

            //creating file instance to reference text file in java
            File text = new File ("___this is the file directory__");

            //creating scanner instance to scan the string
            Scanner scnr = new scanner (text);

            //reading each line of the file using scanner class
            int lineNumber = 1;
            while(scnr.hasNextLine()) {
                string line = scnr.nextline();
            }
        }
    }

    @Override
    Public class main class {
        public static void main (string[] arg) {
            string [] arrayOfString = dataset.txt;
            for (int i=0; i<arrayOfString.length; i++) {

                if(arrayOfString[i].equal(dataset.txt)
                system.out.printIn ("The file contain Ransomware virus");

                else
                system.out.printIn ("File is clean");
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is
        present.
                getMenuInflater().inflate(R.menu.menu_page_scan, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
